import discord
import subprocess
from dotenv import load_dotenv
import os
import re

load_dotenv()

intents = discord.Intents.default()
intents.members = True
intents.messages = True
client = discord.Client(intents=intents)

# Discord Bot Token
TOKEN = os.getenv('TOKEN')

# Server path and name
SERVER_PATH = os.getenv('SERVER_PATH')
SERVER_NAME = os.getenv('SERVER_NAME')

# Server command aliases
COMMANDS = {
    'start': 'start',
    'st': 'start',
    'restart': 'restart',
    'r': 'restart',
    'monitor': 'monitor',
    'm': 'monitor',
    'test-alert': 'test-alert',
    'ta': 'test-alert',
    'details': 'details',
    'dt': 'details',
    'postdetails': 'postdetails',
    'pd': 'postdetails',
    'skeleton': 'skeleton',
    'sk': 'skeleton',
    'update-lgsm': 'update-lgsm',
    'ul': 'update-lgsm',
    'update': 'update',
    'u': 'update',
    'check-update': 'check-update',
    'cu': 'check-update',
    'force-update': 'force-update',
    'fu': 'force-update',
    'validate': 'validate',
    'v': 'validate',
    'backup': 'backup',
    'b': 'backup',
    'console': 'console',
    'c': 'console',
    'debug': 'debug',
    'd': 'debug',
    'mods-install': 'mods-install',
    'mi': 'mods-install',
    'mods-remove': 'mods-remove',
    'mr': 'mods-remove',
    'mods-update': 'mods-update',
    'mu': 'mods-update',
    'install': 'install',
    'i': 'install',
    'auto-install': 'auto-install',
    'ai': 'auto-install',
    'developer': 'developer',
    'dev': 'developer',
    'stop': 'stop',
    'sp': 'stop'
}

def is_user_allowed(author_id):
    allowed_user_ids = os.getenv('ALLOWED_USER_IDS').split(',')
    return str(author_id) in allowed_user_ids

def remove_color_codes(string):
    """Removes color codes from a string."""
    return re.sub(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])', '', string)

@client.event
async def on_ready():
    print(f'{client.user} has connected to Discord!')


@client.event
async def on_message(message):
    if not is_user_allowed(message.author.id):
        return

    if message.author == client.user:
        return

    if message.content.startswith('!'):
        command = message.content[1:]
        if command in COMMANDS:
            full_command = f"./{SERVER_NAME} {COMMANDS[command]}"
            result = subprocess.run(full_command.split(), cwd=SERVER_PATH, stdout=subprocess.PIPE)
            output = result.stdout.decode()
            output = remove_color_codes(output)  # remove color codes
            chunks = [output[i:i+1900] for i in range(0, len(output), 1900)]
            for chunk in chunks:
                await message.channel.send(f"```{chunk}```")


def main():
    client.run(TOKEN)

if __name__ == '__main__':
    main()
