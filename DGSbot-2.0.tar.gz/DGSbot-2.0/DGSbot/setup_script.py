import os
import dotenv

def setup():
    dotenv_path = os.path.expanduser('~/.env')
    with open(dotenv_path, 'w') as f:
        f.write(f"TOKEN={input('Enter your Discord bot token: ')}\n")
        f.write(f"SERVER_PATH={input('Enter your server path: ')}\n")
        f.write(f"SERVER_NAME={input('Enter your server name: ')}\n")
        f.write(f"ALLOWED_USER_IDS={input('Enter your allowed user IDs: ')}\n")

if __name__ == '__main__':
    setup()
