Run the bot with command DGSbot

