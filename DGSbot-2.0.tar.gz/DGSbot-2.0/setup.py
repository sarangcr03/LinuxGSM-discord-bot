from setuptools import setup, find_packages

setup(
    name='DGSbot',
    version='2.0',
    packages=find_packages(),
    install_requires=[
        'discord.py',
        'python-dotenv',
    ],
    entry_points={
        'console_scripts': [
            'DGSbot=DGSbot.__main__:main',
            'DGSbot-setup=DGSbot.setup_script:setup',
        ]
    }
)
