from setuptools import setup, find_packages

setup(
    name='DGSbot',
    version='1.0',
    packages=['DGSbot'],
    install_requires=[
        'discord.py',
        'python-dotenv',
    ],
    entry_points={
        'console_scripts': [
            'DGSbot=DGSbot.__main__:main',
            'DGSbot-setup=DGSbot.setup_script:setup',
        ]
    }
)
